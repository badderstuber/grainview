G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*
G04 #@! TF.CreationDate,2026-10-14T14:43:36+01:00*
G04 #@! TF.ProjectId,grainview_panel,67726169-6e76-4696-9577-5f70616e656c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-14 14:43:36*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
